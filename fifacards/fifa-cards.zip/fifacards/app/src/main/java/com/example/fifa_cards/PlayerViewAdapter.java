package com.example.fifa_cards;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PlayerViewAdapter extends RecyclerView.Adapter<PlayerViewAdapter.MyViewHolder>   {
    private ArrayList<ListPlayers> mDataset;

    static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView position;
        TextView getPlayerImage;
        TextView pac;
        TextView sho;
        TextView pas;
        TextView dri;
        TextView def;
        TextView phy;

        MyViewHolder(View v) {
            super(v);
            name = v.findViewById(R.id.player_name);
            position = v.findViewById(R.id.position);
            getPlayerImage = v.findViewById(R.id.imageView);
            pac = v.findViewById(R.id.pac);
            sho = v.findViewById(R.id.sho);
            pas = v.findViewById(R.id.pas);
            dri = v.findViewById(R.id.dri);
            def = v.findViewById(R.id.def);
            phy = v.findViewById(R.id.phy);
        }
    }

    PlayerViewAdapter(ArrayList<ListPlayers> myDataset) {
        mDataset = myDataset;
    }

    @NonNull
    @Override
    public PlayerViewAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        TextView v = (TextView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_players, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        ListPlayers players = mDataset.get(position);
        String name = players.getName();

        holder.name.setText(name);
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }
}
